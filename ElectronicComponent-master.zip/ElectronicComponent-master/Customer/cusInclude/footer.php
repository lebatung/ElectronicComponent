
<!-- Jquery and Boostrap JavaScript -->
<script type="text/javascript" src="../js/jquery.min.js"></script>
<script type="text/javascript" src="../js/popper.min.js"></script>

<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/bootstrap_thang.min.js"></script>

<!-- Font Awesome JS -->
<script type="text/javascript" src="../js/all.min.js"></script>

<!-- Admin Ajax Call JavaScript -->

<!-- Custom JavaScript -->

<script type="text/javascript" src="../js/ajaxrequest.js"></script>

<script type="text/javascript" src="../js/ajaxTaiDuLieuDiaChi.js"></script>
<script type="text/javascript" src="../js/ajaxCapNhatDiaChi.js"></script>
<script type="text/javascript" src="../js/ajaxThemDiaChi.js"></script>



</body>

</html>
<?php ob_flush(); ?>