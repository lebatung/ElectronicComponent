    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript" src="../js/popper.min.js"></script>
    <script type="text/javascript" src="../js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script type="text/javascript" src="../js/all.min.js"></script>

    
    <script type="text/javascript" src="../js/staff.js"></script>
    <script type="text/javascript" src="../js/nguoiBan.js"></script>
    </body>
</html>